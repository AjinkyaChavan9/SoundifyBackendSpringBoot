package com.soundify.dtos;

public class ArtistSignupRequestDTO {

}
